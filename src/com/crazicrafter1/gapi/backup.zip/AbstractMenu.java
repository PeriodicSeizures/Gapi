package com.crazicrafter1.gapi;

public class AbstractMenu {



}
